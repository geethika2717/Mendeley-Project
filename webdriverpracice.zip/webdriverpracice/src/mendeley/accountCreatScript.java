package mendeley;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class accountCreatScript {

	

		public static void main(String[] args) throws Exception {
			// TODO Auto-generated method stub

			//create browser instance
		System.setProperty("webdriver.chrome.driver", "/Users/geethikamantravadi1/Desktop/seleniumsoft/chromedriver");
			
			//create a browser instance
			
			WebDriver menddriver=new ChromeDriver();
			
			//open test application
			menddriver.get("http://www.mendeley.com");
			Thread.sleep(3000);
			//menddriver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
			
		   //maximize the window
			menddriver.manage().window().maximize();
			
			//click on sign in button
			
			accountCreatob.link_signin(menddriver).click();
			Thread.sleep(2000);
			accountCreatob.email_input(menddriver).sendKeys("abc@gmail.com");
			accountCreatob.first_name(menddriver).sendKeys("abcdefg");
			accountCreatob.last_name(menddriver).sendKeys("xyzqwerty");
			accountCreatob.password(menddriver).sendKeys("abcxyz1");
			accountCreatob.continue_button(menddriver).click();
			accountCreatob.subject_area(menddriver).click();
			Thread.sleep(3000);
			accountCreatob.user_role(menddriver).click();
			Thread.sleep(2000);
			accountCreatob.createaccount_button(menddriver).click();
			Thread.sleep(2000);
			accountCreatob.text_exists(menddriver).getText();
	
	}

}