package mendeley;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;



	public class accountCreatob {

		public static WebElement mendelement; 
		//sign in link
		public static WebElement link_signin(WebDriver menddriver)
		{
			
			mendelement=menddriver.findElement(By.xpath("//a[@title = 'Create a free account']"));
			return mendelement;
		}
		
		//email
		
		public static WebElement email_input(WebDriver menddriver)
		{
			mendelement=menddriver.findElement(By.id("email"));
			return mendelement;
		}
		
		public static WebElement first_name(WebDriver menddriver)
		{
			mendelement=menddriver.findElement(By.id("first_name"));
			return mendelement;
		}
		public static WebElement last_name(WebDriver menddriver)
		{
			mendelement=menddriver.findElement(By.id("last_name"));
			return mendelement;
		}
		public static WebElement password(WebDriver menddriver)
		{
			mendelement=menddriver.findElement(By.id("password"));
			return mendelement;
		}

		public static WebElement continue_button(WebDriver menddriver)
		{
			mendelement=menddriver.findElement(By.xpath("//button[@type= 'submit']"));
			return mendelement;
		}	
		
		public static WebElement subject_area(WebDriver menddriver)
		{
			
			mendelement= menddriver.findElement(By.name("subject_area"));
			Select saselect=new Select(mendelement);
			//saselect.selectByVisibleText("Agricultural and Biological Sciences");
			saselect.selectByVisibleText("Arts and Humanities");
			return mendelement;
			

	    }

		public static WebElement user_role(WebDriver menddriver)
		{
			mendelement=menddriver.findElement(By.name("user_role"));
			Select usraselect=new Select(mendelement);
			usraselect.selectByVisibleText("Lecturer");
			return mendelement;
		
	    }
		public static WebElement createaccount_button(WebDriver menddriver)
		{
			mendelement=menddriver.findElement(By.id("join-form-submit"));
			return mendelement;
		}
		public static WebElement text_exists(WebDriver menddriver)
		{
			
			if(menddriver.getPageSource().contains("Mendeley account found"))
			{
				System.out.println("account created so found");
			}
				else
				{
					System.out.println("account not created");
			}
			return mendelement;
		}
		
		
	}
